﻿using System;
using System.Threading.Tasks;
using Microsoft.Identity.Client;
using Microsoft.Graph;
using Microsoft.Graph.Auth;

namespace az204_authdemo
{
    public class Program
    {
        private const string _clientId = "d0db102a-88b5-4243-93d1-cd8f3ddb003e";
        private const string _tenantId = "5ebc7bc9-654b-4f94-b66d-ac8b3745ddba";
        //static void Main(string[] args)
        public static async Task Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            var app = PublicClientApplicationBuilder
                .Create(_clientId)
                .WithAuthority(AzureCloudInstance.AzurePublic, _tenantId)
                .WithRedirectUri("http://localhost")
                .Build();
            string[] scopes = { "user.read" };
           
            //AuthenticationResult result = await app.AcquireTokenInteractive(scopes).ExecuteAsync();
            //Console.WriteLine($"Token:\t{result.AccessToken}");

            var provider = new InteractiveAuthenticationProvider(app, scopes);
            var client = new GraphServiceClient(provider);

            User me = await client.Me.Request().GetAsync();
            Console.WriteLine($"Display Name:\t{me.DisplayName}");
        }
    }
}
