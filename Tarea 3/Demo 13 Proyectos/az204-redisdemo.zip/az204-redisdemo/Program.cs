﻿using System;
using StackExchange.Redis;
using System.Threading.Tasks;

namespace az204_redisdemo
{
    class Program
    {
        //static void Main(string[] args)
        static async Task Main(string[] args)
        {
            string connectionString = "az204redisjagh.redis.cache.windows.net:6380,password=5GyS5JrVM3A8ZEyf752auJF5GnVbl9jb4kytB+mpZhw=,ssl=True,abortConnect=False";

            using (var cache = ConnectionMultiplexer.Connect(connectionString))
            {
                IDatabase db = cache.GetDatabase();
                bool setValue = await db.StringSetAsync("test:key", "100");
                Console.WriteLine($"SET: {setValue}");
                string getValue = await db.StringGetAsync("test:key");
                Console.WriteLine($"GET: {getValue}");

                var result = await db.ExecuteAsync("ping");
                Console.WriteLine($"PING = {result.Type} : {result}");

                result = await db.ExecuteAsync("flushdb");
                Console.WriteLine($"FLUSHDB = {result.Type} : {result}");

            }
        }
    }
}
